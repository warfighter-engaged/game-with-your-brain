Arduino Code for printing EEG attention
================

Add the .zip file from the directory as a library to the Arduino IDE by going to Sketch > Include library > Add ZIP library.

Open the example at File/Examples/Mindwave-WarfighterEngaged/CodeForArduino/PrintAttention and upload it to the Arduino. The wire to the Rx pin (0) will have to be unplugged or you will get an error. Plug it back after uploading, and see the console for the Serial port at 57600 bauds.

Reference:
https://github.com/redpaperheart/ArduinoMindwave